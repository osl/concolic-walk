
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample81 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark81(0, 0);
  }

}