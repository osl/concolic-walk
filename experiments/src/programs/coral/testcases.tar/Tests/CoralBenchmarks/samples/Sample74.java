
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample74 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark74(0, 0, 0, 0, 0, 0, 0, 0);
  }

}