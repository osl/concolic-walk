
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample31 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark31(0);
  }

}