
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample29 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark29(0);
  }

}