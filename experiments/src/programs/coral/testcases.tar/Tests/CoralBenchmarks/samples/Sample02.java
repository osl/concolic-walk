
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample02 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark02(0, 0);
  }

}