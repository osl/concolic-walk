
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample49 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark49(0, 0);
  }

}