
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample37 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark37(0, 0, 0);
  }

}