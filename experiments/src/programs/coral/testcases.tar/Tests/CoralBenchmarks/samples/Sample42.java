
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample42 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark42(0, 0);
  }

}