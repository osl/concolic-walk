
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample30 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark30(0);
  }

}