
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample41 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark41(0, 0);
  }

}