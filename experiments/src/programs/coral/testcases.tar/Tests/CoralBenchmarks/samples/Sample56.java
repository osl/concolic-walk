
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample56 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark56(0, 0, 0, 0, 0);
  }

}