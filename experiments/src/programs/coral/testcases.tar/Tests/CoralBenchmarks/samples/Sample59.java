
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample59 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark59(0, 0, 0, 0, 0);
  }

}