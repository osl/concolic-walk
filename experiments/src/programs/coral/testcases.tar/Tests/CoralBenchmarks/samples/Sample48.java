
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample48 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark48(0, 0, 0);
  }

}