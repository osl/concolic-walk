
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample03 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark03(0, 0);
  }

}