
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample83 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark83(0, 0);
  }

}