
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample12 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark12(0, 0, 0, 0);
  }

}