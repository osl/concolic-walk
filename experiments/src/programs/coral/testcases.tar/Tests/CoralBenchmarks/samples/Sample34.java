
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample34 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark34(0);
  }

}