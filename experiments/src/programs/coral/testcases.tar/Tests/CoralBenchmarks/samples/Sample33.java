
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample33 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark33(0);
  }

}