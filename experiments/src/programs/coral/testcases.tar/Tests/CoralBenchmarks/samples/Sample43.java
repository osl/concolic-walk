
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample43 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark43(0, 0);
  }

}