
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample61 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark61(0, 0, 0, 0);
  }

}