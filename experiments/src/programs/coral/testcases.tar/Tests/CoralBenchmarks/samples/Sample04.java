
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample04 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark04(0);
  }

}