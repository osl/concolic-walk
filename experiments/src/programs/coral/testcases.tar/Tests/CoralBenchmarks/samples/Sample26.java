
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample26 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark26(0, 0, 0, 0, 0);
  }

}