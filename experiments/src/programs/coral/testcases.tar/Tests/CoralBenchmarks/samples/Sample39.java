
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample39 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark39(0, 0);
  }

}