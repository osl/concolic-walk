
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample76 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark76(0, 0, 0, 0, 0, 0, 0, 0, 0);
  }

}