
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample63 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark63(0, 0, 0, 0, 0);
  }

}