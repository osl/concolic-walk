
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample78 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark78(0, 0, 0, 0, 0, 0, 0, 0);
  }

}