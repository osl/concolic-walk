
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample17 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark17(0);
  }

}