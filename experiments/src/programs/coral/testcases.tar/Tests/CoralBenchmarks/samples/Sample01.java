
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample01 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark01(0, 0);
  }

}