
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample51 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark51(0, 0);
  }

}