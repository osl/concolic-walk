
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample18 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark18(0);
  }

}