
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample53 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark53(0, 0, 0);
  }

}