
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample11 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark11(0, 0, 0, 0);
  }

}