
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample75 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark75(0, 0, 0, 0, 0, 0, 0, 0, 0);
  }

}