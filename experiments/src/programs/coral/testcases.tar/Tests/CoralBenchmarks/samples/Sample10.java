
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample10 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark10(0, 0, 0);
  }

}