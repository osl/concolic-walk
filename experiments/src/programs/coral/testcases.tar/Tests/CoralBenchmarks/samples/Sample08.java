
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample08 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark08(0, 0, 0);
  }

}