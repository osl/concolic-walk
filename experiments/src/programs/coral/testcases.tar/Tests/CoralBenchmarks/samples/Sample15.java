
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample15 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark15(0, 0, 0, 0);
  }

}