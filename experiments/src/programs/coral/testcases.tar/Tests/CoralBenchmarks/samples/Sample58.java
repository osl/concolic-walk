
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample58 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark58(0, 0, 0, 0, 0);
  }

}