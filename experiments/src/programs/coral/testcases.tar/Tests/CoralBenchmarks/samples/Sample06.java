
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample06 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark06(0, 0, 0);
  }

}