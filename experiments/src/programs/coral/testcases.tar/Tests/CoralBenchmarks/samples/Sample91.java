package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample91 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark91(0, 0);
  }

}
