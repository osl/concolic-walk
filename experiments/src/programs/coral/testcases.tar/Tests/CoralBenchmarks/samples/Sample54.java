
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample54 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark54(0, 0, 0);
  }

}