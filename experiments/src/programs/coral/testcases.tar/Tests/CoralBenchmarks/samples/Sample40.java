
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample40 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark40(0, 0);
  }

}