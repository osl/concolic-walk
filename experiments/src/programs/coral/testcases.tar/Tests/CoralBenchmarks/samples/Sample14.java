
package coral.tests.samples;

import coral.tests.JPFBenchmark;

public class Sample14 {

  public static void main(String[] args) {
    JPFBenchmark.benchmark14(0, 0, 0, 0);
  }

}