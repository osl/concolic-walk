package gov.nasa.jpf.util;

public interface Processor<T> {
  void process(T obj);
}
