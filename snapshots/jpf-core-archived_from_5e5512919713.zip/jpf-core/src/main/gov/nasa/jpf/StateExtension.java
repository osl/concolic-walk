package gov.nasa.jpf;

public interface StateExtension {

}
