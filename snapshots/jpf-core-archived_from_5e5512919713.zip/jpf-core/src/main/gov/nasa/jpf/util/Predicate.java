package gov.nasa.jpf.util;

public interface Predicate<T> {

  boolean isTrue (T subject);
}
