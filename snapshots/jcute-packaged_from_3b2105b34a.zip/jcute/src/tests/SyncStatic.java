package tests;



/**
 *  .
 * User: Koushik Sen (ksen@cs.uiuc.edu)
 * Date: Nov 7, 2005
 * Time: 10:26:10 AM
 */
public class SyncStatic{
    public static void main(String[] args) {
        double x;
        double d = 100;
        x = (int)d+1;
        System.out.println("d = " + d);
    }
}

