package tests;

import java.util.Stack;

/**
 * Author: Koushik Sen <ksen@cs.uiuc.edu>
 */
public class StackTest {
    public static void main(String[] args) {
        Stack s = new Stack();
        s.push(null);
        s.pop();
    }
}
