package randoop;

public @interface RandoopStat {

  String value();
  
}
