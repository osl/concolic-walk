package randoop.util;

public interface WeightedElement {

  double getWeight();
}
