package randoop.test.health;
/**
 * A class to contains the results from the health care simulation.
 **/
public class Results
{
  float totalPatients;
  float totalTime;
  float totalHospitals;
}
