package randoop.test;

import junit.framework.TestCase;

public class DisabledTests extends TestCase {

}
