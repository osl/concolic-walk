package randoop.test;


public class A2 extends A {

}
