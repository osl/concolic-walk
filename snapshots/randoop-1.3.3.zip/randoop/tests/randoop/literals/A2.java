package randoop.literals;

//Class for testing literal files.
public class A2 extends A {

  public A2(int i) {
    super(i);
  }
  public void test(byte b) { }
  public void test(char c) { }
  public void test(short s) { }
  public void test(int i) { }
  public void test(long l) { }
  public void test(double d) { }
  public void test(float f) { }
  public void test(String s) { }
  
}
