package mcdrivertest;

import java.util.List;

public class BugHelper {
    
    public static void addNewObject(List l) {
        l.add(new Object());
    }

}
